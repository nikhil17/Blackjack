/**
 * Created by nikhil on 3/9/18.
 */
public enum SuitEnum {
    SPADES,
    CLOVES,
    HEARTS,
    DIAMONDS
}
