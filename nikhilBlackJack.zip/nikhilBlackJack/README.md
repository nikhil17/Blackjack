#How to run



#Known Issues

Players who have two cards with the same number (value) can't double down, they can only split.

Hand.getHandValue should be renamed
Write methods for players busting/ winning instead of copying the print statements


#Potential new features

Allow players to join in between rounds as well as leave.
